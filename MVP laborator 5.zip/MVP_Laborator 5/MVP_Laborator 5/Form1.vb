﻿Public Class Form1
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim venit As Double
        Dim sumaMax As Double
        Dim alteCredite As Double
        Dim nrLuni As Integer
        Dim decizie As String
        Dim sumaPosibila As Double
        Dim luniMax As Double
        Dim notificare As Integer

        venit = TextBox1.Text
        sumaMax = venit * 45 / 100
        TextBox2.Text = sumaMax


        alteCredite = TextBox3.Text
        nrLuni = TextBox6.Text
        sumaPosibila = sumaMax - alteCredite

        If alteCredite > 0 Then
            'daca are credite mai mari decat 45% din venit net
            If alteCredite > sumaMax Then
                TextBox4.Text = "Nu va putem oferi credit"



                'daca creditul potential este mai mic de 50 de lei
            ElseIf sumaMax - alteCredite < 50 Then
                TextBox4.Text = "Nu va putem oferi credit"



                'putem oferi credit
            Else

                'daca creditul potential este mai mic de jumatate din suma maxima de indatorare
                If sumaMax - alteCredite < sumaMax / 2 Then
                    'maximul de luni de creditare
                    nrLuni = 12
                    notificare = 1
                End If

                TextBox4.Text = "Va putem oferi credit"
                TextBox5.Text = sumaPosibila

                If notificare = 1 Then
                    nrluni.Text = "Maxim 12 luni"
                Else
                    nrluni.Text = nrLuni
                End If

            End If
        End If



    End Sub

End Class
